# GeoSinglePrior-D36-v1 frozen research bundle

输入为单样品36元素化学组成与经纬度；输出九类概率和唯一硬标签。
不需要同批样品；缺失坐标精确回退D36_74；不拒识。

- D36模型成员：3
- 训练样品：16076
- 空间库Province：227
- 坐标覆盖率：99.5521%
- bundle内容哈希：dd5516221c32400a31f65795a9dbe85e94751ececbe174e35edb4304edfffc09
- 模型往返最大误差：0.000e+00
- 完整概率往返最大误差：0.000e+00
- 单条/批量最大误差：1.504e-17
- 行置换最大误差：0.000e+00
- 严格空间OOF回放最大误差：2.454e-14
- Province OOF回放最大误差：3.331e-16
- 严格西藏回放最大误差：5.829e-16

状态：冻结研究推理包；默认Router未启用；等待外部地区确认。
性能只能引用bundle.json中链接的OOF与严格留出报告，训练回放不能作为性能成绩。

## 命令行

```powershell
.venv\Scripts\python.exe src\predict_geosingle_d36_csv.py `
  --input reports\modeling\geosingle_prior_d36_v1_bundle_2026-10-17\example_input.csv `
  --output reports\modeling\geosingle_prior_d36_v1_bundle_2026-10-17\example_predictions.csv
```

输入CSV必须包含36个D36化学列；Latitude、Longitude可缺失，缺失行自动回退D36。命令同时输出预测CSV和审计JSON。

## Jupyter

可直接运行 `notebooks/GeoSinglePrior_D36_v1_inference_2026-10-17.ipynb`。项目已注册 `AI地学 D36 (.venv)` 内核；已执行副本无错误。
